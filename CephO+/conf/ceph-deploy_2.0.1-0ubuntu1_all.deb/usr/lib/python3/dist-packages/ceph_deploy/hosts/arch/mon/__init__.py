from ceph_deploy.hosts.common import mon_add as add  # noqa
from ceph_deploy.hosts.common import mon_create as create  # noqa
